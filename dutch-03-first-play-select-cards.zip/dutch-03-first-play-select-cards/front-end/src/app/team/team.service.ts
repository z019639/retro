import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {TeamDto, UpsertTeamDto, ResultDto} from './team';
import {BASE_URL, API_BASE, END_POINTS, TOPICS} from '../app-constants';
import {switchMap} from 'rxjs/operators';
import {WebsocketService} from '../websocket.service';

@Injectable({
  providedIn: 'root',
})
export class TeamService {
  private teamsSource$;
  private memberRequestSource$;

  constructor(
    private httpClient: HttpClient,
    private websocketService: WebsocketService
  ) {
    this.teamsSource$ = this.websocketService.observeTopic(TOPICS.TEAMS);
  }

  getAll(searchString: string): Observable<TeamDto[]> {
    if (searchString === '') {
      searchString = 'All';
    }
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.TEAM}/${searchString}/dashboard`;
    return this.websocketService.initializedBoundedDebounce(this.teamsSource$).pipe(
      switchMap(() => this.httpClient.get<TeamDto[]>(url))
    );
  }

  getById(id: number): Observable<TeamDto> {
    if (!this.teamsSource$) {
      this.teamsSource$ = this.websocketService.observeTopic(TOPICS.TEAMS);
    }
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.TEAM}/${id}`;
    return this.websocketService.initializedBoundedDebounce(this.teamsSource$).pipe(
      switchMap(() => this.httpClient.get<TeamDto>(url))
    );
  }

  joinTeam(id: number, joiningId: string, username: string): Observable<number> {
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.TEAM}/${id}/${joiningId}/${username}`;
    return this.httpClient.get<number>(url);
  }

  getJoiningCode(id: number): Observable<ResultDto> {
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.TEAM}/${id}/joining-code`;
    return this.httpClient.get<ResultDto>(url);
  }

  startCountDown(id: number): Observable<ResultDto> {
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.TEAM}/${id}/start-count-down`;
    return this.httpClient.post<ResultDto>(url, {});
  }

  changeColumnColor(id: number, columnIndex: number, selectedColor: string): Observable<ResultDto> {
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.TEAM}/${id}/change-column-color/${columnIndex}`;
    return this.httpClient.post<ResultDto>(url, selectedColor);
  }

  add(teamDto: UpsertTeamDto): Observable<string> {
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.TEAM}`;
    return this.httpClient.post(url, teamDto, {responseType: 'text'});
  }

  update(teamDto: UpsertTeamDto): Observable<string> {
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.TEAM}/update`;
    return this.httpClient.post(url, teamDto, {responseType: 'text'});
  }

  initMemberRequestSubscription(memberId: number): void {
    const topic = `${TOPICS.MEMBERS}/${memberId}`;
    this.websocketService.observeRequestTopic(topic);
  }
}
