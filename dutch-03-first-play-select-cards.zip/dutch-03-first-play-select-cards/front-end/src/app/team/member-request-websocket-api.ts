import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import {TeamComponent} from './team.component';
import {BASE_URL, END_POINTS} from '../app-constants';

export class MemberRequestWebSocketAPI {
  teamComponent: TeamComponent;

  private webSocketEndPoint = `${BASE_URL}/${END_POINTS.WEB_SOCKET}`;
  private stompClient: any;

  constructor(teamComponent: TeamComponent) {
    this.teamComponent = teamComponent;
  }

  _connect() {
    const webSocket = new SockJS(this.webSocketEndPoint);
    this.stompClient = Stomp.over(webSocket);
    this.stompClient.connect({}, {}, {});
  }

  _disconnect() {
    if (this.stompClient !== null) {
      this.stompClient.disconnect();
    }
  }
}
