import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TeamStateComponent } from './team-state.component';

describe('TeamStateComponent', () => {
  let component: TeamStateComponent;
  let fixture: ComponentFixture<TeamStateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TeamStateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TeamStateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
