import {Component, Input} from '@angular/core';
import {TeamState} from '../../team';

@Component({
  selector: 'app-team-state',
  templateUrl: './team-state.component.html',
  styleUrls: ['./team-state.component.scss']
})
export class TeamStateComponent {
  @Input()
  state: TeamState = TeamState.OPEN;
}
