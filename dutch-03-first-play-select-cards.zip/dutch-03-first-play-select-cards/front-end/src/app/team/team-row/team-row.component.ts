import { Component, Input, Output, EventEmitter } from '@angular/core';
import {TeamDto, TeamState} from '../team';
import {Router} from '@angular/router';
import {TeamService} from '../team.service';

@Component({
  selector: 'app-team-row',
  templateUrl: './team-row.component.html',
  styleUrls: ['./team-row.component.scss']
})
export class TeamRowComponent {
  @Input()
  team: TeamDto;
  @Output()
  teamId: EventEmitter<number> = new EventEmitter();
  @Output()
  joiningCode: EventEmitter<string> = new EventEmitter();

  currentUserId: number;

  TeamState = TeamState;

  constructor(private teamService: TeamService) {
    this.currentUserId = localStorage.getItem('userId') ? parseInt(localStorage.getItem('userId')) : 0;
  }

  joinTeamModalOpen(): void {
    this.teamId.emit(this.team._id);
  }

  getJoiningCode(): void {
    this.teamService.getJoiningCode(this.team._id).subscribe(resultDto => {
      this.joiningCode.emit(resultDto.result);
    });
  }
}
