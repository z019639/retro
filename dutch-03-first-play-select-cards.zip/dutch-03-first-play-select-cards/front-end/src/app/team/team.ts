import {MemberDto, Card} from '../member/member';

export enum TeamState {
  OPEN = 'OPEN',
  STARTED = 'STARTED',
  CLOSED = 'CLOSED'
}

export class TeamDto {
  constructor(_id: number) {
    this._id = _id;
  }

  _id: number;
  name: string;
  noOfColumns: number;
  columnNames: string[];
  columnColours: string[];
  joiningId: string;
  countDownStarted: Date;
  members: MemberDto[];
  createdBy: MemberDto;
  createdAt: Date;
  updatedAt: Date;
}

export class UpsertTeamDto {
  _id: number;
  name = '';
  noOfColumns = 0;
  columnNames: string[] = [];
  columnColours: string[] = [];
  createdBy: MemberDto;
  state: TeamState = TeamState.OPEN;
}

export class ResultDto {
  result: string;
}
