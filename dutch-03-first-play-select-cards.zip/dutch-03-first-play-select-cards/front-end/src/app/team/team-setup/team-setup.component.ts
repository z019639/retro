import {Component, OnInit, OnDestroy} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import {UpsertMemberDto, MemberDto, MemberState, CardDisplay} from 'src/app/member/member';
import {TeamDto, UpsertTeamDto} from '../team';
import {TeamService} from '../team.service';
import {Subscription} from 'rxjs';
import {Card} from './../../member/member';
import {MemberService} from 'src/app/member/member.service';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-team-setup',
  templateUrl: './team-setup.component.html',
  styleUrls: ['./team-setup.component.scss']
})
export class TeamSetupComponent implements OnInit, OnDestroy {
  member: UpsertMemberDto = new UpsertMemberDto();
  teamDto: TeamDto;
  team: UpsertTeamDto = new UpsertTeamDto();
  members: MemberDto[];
  filteredMembers: MemberDto[] = [];
  memberName: string;
  MemberState = MemberState;
  memberId: number;
  card: Card = new Card();
  columnEdit: {index: number, value: string} = {index: null, value: null};
  columnWidth: {};
  cardsArray: any = [];
  canRemoveAnimate = false;
  canAddCards = true;
  isTimerStarted = false;

  private teamId: number;
  private teamSubscription$: Subscription;
  private richText: HTMLElement;

  constructor(
    private activatedRoute: ActivatedRoute,
    private teamService: TeamService,
    private memberService: MemberService,
    private toastrService: ToastrService
  ) {
    this.teamId = this.activatedRoute.snapshot.params.teamId;
    this.teamDto = new TeamDto(this.teamId);
  }

  ngOnInit(): void {
    this.getMemberId();
    this.getTeamDetails();
    setTimeout(() => {
      this.canRemoveAnimate = true;
    }, 2250);
  }

  ngOnDestroy(): void {
    this.teamSubscription$.unsubscribe();
  }

  startTimer(): void {
    this.teamService.startCountDown(this.teamId).subscribe();
  }

  initiateTimer(endTime: Date): void {
    this.isTimerStarted = true;
    const id = 'clock';
    const clock = document.getElementById(id);
    const minutesSpan = clock.querySelector('.minutes');
    const secondsSpan = clock.querySelector('.seconds');
    let $this = this;
    function updateClock(__this) {
      const total = Date.parse(endTime.toString()) - Date.parse(new Date().toString());
      const seconds = Math.floor((total / 1000) % 60);
      const minutes = Math.floor((total / 1000 / 60) % 60);
      const timer = {
        total,
        minutes,
        seconds
      };

      minutesSpan.innerHTML = ('0' + timer.minutes).slice(-2);
      secondsSpan.innerHTML = ('0' + timer.seconds).slice(-2);

      if (timer.total < 0) {
        __this.isTimerStarted = false;
        clearInterval(timeInterval);
      }
    }

    const timeInterval = setInterval(() => {
      updateClock($this);
    }, 1000);
    updateClock($this);
  }

  update(): void {
    if (this.columnEdit.value !== null) {
      this.teamDto.columnNames[this.columnEdit.index] = this.columnEdit.value;
    }
    this.team.columnNames = this.teamDto.columnNames;
    this.teamService.update(this.team).subscribe(result => {
      this.columnEdit = {index: null, value: null};
    });
  }

  editColumnName(index: number): void {
    this.columnEdit.index = index;
    this.columnEdit.value = this.teamDto.columnNames[index];
  }

  addNote(index: number): void {
    this.card.index = index;
  }

  deleteNoteByIndex(index: number): void {
    this.memberService.deleteCardByIdAndIndex(this.memberId, index).subscribe();
  }

  addVote(index: number, cardCreatorId: number, event): void {
    if (cardCreatorId !== this.memberId) {
      this.memberService.addVoteByCardIndexAndMemberId(this.memberId, cardCreatorId, index).subscribe();
    }
  }

  openColorPicker(index: number): void {
    document.getElementById('color' + index).click();
  }

  changeColumnColor(columnIndex: number): void {
    const color = document.getElementById('color' + columnIndex)['value'];
    this.teamService.changeColumnColor(this.teamId, columnIndex, color).subscribe();
  }

  saveCard(): void {
    if (this.canSaveNote()) {
      this.memberService.updateById(this.memberId, this.card).subscribe(result => {
        this.card = new Card();
      }, error => {
          console.log(error);
      });
    } else {
      this.toastrService.warning('Content length should be greater than 0 and less than 150 characters.');
    }
  }

  canSaveNote(): boolean {
    this.richText = document.createElement('Dummy');
    this.richText.innerHTML = this.card.note;
    const totalLength = this.richText.innerText.length;
    return !(totalLength < 1 || totalLength > 150);
  }

  private getMemberId(): void {
    this.memberId = localStorage.getItem('userId') ? parseInt(localStorage.getItem('userId')) : 0;
  }

  private getTeamDetails(): void {
    this.teamSubscription$ = this.teamService.getById(this.teamId)
      .subscribe(team => {
        this.teamDto = team;
        const cards: CardDisplay[] = team.members
          .map(member => member.cards ? member.cards.map((card, index) => {
            const cardDisplay: CardDisplay = new CardDisplay();
            cardDisplay.index = card.index;
            cardDisplay.note = card.note;
            cardDisplay.votes = card.votes;
            cardDisplay.member = member.name;
            cardDisplay.cardIndex = index;
            cardDisplay.memberId = member._id;
            return cardDisplay;
          }) : [])
          .reduce((acc, val) => acc.concat(val), []);
        this.cardsArray = [];
        for (let i = 0; i < team.columnNames.length; i++) {
          this.cardsArray.push(cards.filter(card => card.index === i));
        }
        if (team.countDownStarted) {
          this.initiateTimer(team.countDownStarted);
        }
        this.canAddCards = this.cardsArray.length <= 50;
        this.columnWidth = {width: 100 / team.columnNames.length + 'px'};
        this.team._id = this.teamId;
        this.team.name = this.teamDto.name;
      });
  }
}
