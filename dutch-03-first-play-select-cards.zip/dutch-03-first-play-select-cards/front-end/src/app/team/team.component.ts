import {Component, OnInit, OnDestroy} from '@angular/core';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import {TeamService} from './team.service';
import {TeamDto, UpsertTeamDto} from './team';
import {Subscription, Subject} from 'rxjs';
import {BASE_URL, END_POINTS, BASE_TOPIC, TOPICS, LOCAL_STORAGE} from '../app-constants';
import {Router} from '@angular/router';
import {ToastrService} from 'ngx-toastr';
import {MemberDto} from '../member/member';
import {tap, switchMap, takeUntil} from 'rxjs/operators';

@Component({
  selector: 'app-team',
  templateUrl: './team.component.html',
  styleUrls: ['./team.component.scss']
})
export class TeamComponent implements OnInit, OnDestroy {
  teamDto: UpsertTeamDto = new UpsertTeamDto();
  teamDtos: TeamDto[];
  teamId: number;
  userId: number;
  username: string;
  joiningCode: string;
  searchString: string = '';

  private teamSubscription$: Subject<TeamDto[]> = new Subject<TeamDto[]>();
  private onDestroy$: Subject<void> = new Subject<void>();
  private columnColors: string[] = ['#f1425e', '#FFD422', '#006DF0', '#00BF96', '#e98737', '#bf7adf'];

  constructor(private router: Router, private teamService: TeamService, private toastrService: ToastrService) {}

  ngOnInit(): void {
    this.getAll();
    this.teamSubscription$.next();
  }

  ngOnDestroy(): void {
    this.teamSubscription$.unsubscribe();
  }

  checkUserExistence(): void {
    this.userId = localStorage.getItem('userId') ? parseInt(localStorage.getItem('userId')) : null;
  }

  add(): void {
    this.teamDto.createdBy = new MemberDto();
    this.teamDto.columnColours = this.columnColors;
    if (this.userId !== null && this.userId !== 0) {
      this.teamDto.createdBy._id = this.userId;
    } else {
      this.teamDto.createdBy.name = this.username;
    }

    this.teamService.add(this.teamDto).subscribe(result => {
      localStorage.setItem('userId', result.toString());
      this.teamDto.name = '';
    });
  }

  addColumn(): void {
    if (this.teamDto.columnNames.length <= 5) {
      this.teamDto.columnNames.push('');
    } else {
      this.toastrService.warning('Limit exceeded');
    }
  }

  setTeamId(event): void {
    this.teamId = event;
  }

  setJoiningCode(event): void {
    this.joiningCode = event;
  }

  joinTeam(teamId: number, joiningId: string, username: string): void {
    if (this.userId) {
      username = null;
    }
    this.teamService.joinTeam(teamId, joiningId, username).subscribe(result => {
      if (result !== 0) {
        if (result !== null && !localStorage.getItem('userId')) {
          localStorage.setItem('userId', result.toString());
        }
        this.router.navigate([`team/${teamId}/team-setup`]);
      }
    });
  }

  addValue(index: number, value: string): void {
    this.teamDto.columnNames[index] = value;
  }

  searchRefresh(): void {
    if (this.searchString === '') {
      setTimeout(() => {
        if (this.searchString === '') {
          this.searchTeam();
        }
      }, 2000);
    }
  }

  searchTeam(): void {
    this.teamSubscription$.next();
  }

  private getAll(): void {
    this.teamSubscription$.pipe(
      tap(() => console.log('status')),
      switchMap(() =>
        this.teamService.getAll(this.searchString),
      ),
      takeUntil(this.onDestroy$),
    )
    .subscribe(
      teams => {
        this.teamDtos = teams;
        this.checkUserExistence();
      },
      error => {
        console.error('An error occurred while loading teams', error);
      },
    );
  }
}
