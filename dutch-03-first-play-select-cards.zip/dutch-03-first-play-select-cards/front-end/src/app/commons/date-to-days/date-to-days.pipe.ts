import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'dateToDays'
})
export class DateToDaysPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (value !== null) {
      const lastSeenDate = new Date(value);
      const today = new Date();
      const difference = (today.getTime() - lastSeenDate.getTime()) / 1000;
      const differenceHours = difference / (60 * 60);
      let result;
      if (differenceHours >= 24 && differenceHours < 48) {
        result = `${Math.abs(Math.round(differenceHours / 24))} day ago`;
      } else if (differenceHours > 48) {
        result = `${Math.abs(Math.round(differenceHours / 24))} days ago`;
      } else if (differenceHours < 24 && Math.abs(Math.floor(differenceHours)) > 1) {
        result = `${Math.abs(Math.floor(differenceHours))} hours ago`;
      } else if (Math.abs(Math.floor(differenceHours)) === 1) {
        result = `${Math.abs(Math.round(differenceHours))} hour ago`;
      } else if (Math.abs(Math.floor(differenceHours)) < 1 && Math.abs(Math.floor(difference / 60)) >= 2) {
        result = `${Math.abs(Math.floor(difference / 60))} minutes ago`;
      } else if (Math.abs(Math.floor(difference / 60)) < 2)  {
        result = `Now`;
      }
      return result;
    } else {
      return '-';
    }
  }
}
