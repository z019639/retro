import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {ToastrModule} from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {FormsModule} from '@angular/forms';
import {StompRService} from '@stomp/ng2-stompjs';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {AngularEditorModule} from '@kolkov/angular-editor';
import { NgxWheelModule } from 'ngx-wheel';
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {TeamComponent} from './team/team.component';
import {TeamService} from './team/team.service';
import {WebsocketService} from './websocket.service';
import {FooterComponent} from './base/footer/footer.component';
import {HeaderComponent} from './base/header/header.component';
import {TeamRowComponent} from './team/team-row/team-row.component';
import {MemberComponent} from './member/member.component';
import {MemberService} from './member/member.service';
import {TeamSetupComponent} from './team/team-setup/team-setup.component';
import {TeamStateComponent} from './team/team-row/team-state/team-state.component';
import {DateToDaysPipe} from './commons/date-to-days/date-to-days.pipe';
import {ReplacePipe} from './commons/replace/replace.pipe';
import { FilterPipe } from './commons/filter/filter.pipe';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SpinningWheelComponent } from './spinning-wheel/spinning-wheel.component';

@NgModule({
  declarations: [
    AppComponent,
    TeamComponent,
    HeaderComponent,
    FooterComponent,
    TeamRowComponent,
    MemberComponent,
    TeamSetupComponent,
    TeamStateComponent,
    DateToDaysPipe,
    ReplacePipe,
    FilterPipe,
    DashboardComponent,
    SpinningWheelComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    AngularEditorModule,
    NgbModule,
    FormsModule,
    NgxWheelModule,
    ToastrModule.forRoot({
      autoDismiss: true,
      closeButton: true,
      timeOut: 10000,
      progressBar: true,
      easing: 'ease-in',
      preventDuplicates: true,
    })
  ],
  exports: [TeamRowComponent],
  providers: [
    StompRService,
    WebsocketService,
    TeamService,
    MemberService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
