import {Injectable} from '@angular/core';
import {StompConfig, StompRService} from '@stomp/ng2-stompjs';
import {Message} from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import {NEVER, Observable, of} from 'rxjs';
import {auditTime, distinctUntilChanged, mapTo, merge, switchMap, debounceTime} from 'rxjs/operators';
import {BASE_URL, END_POINTS, APP_CONSTANTS, BASE_TOPIC} from './app-constants';

@Injectable({
  providedIn: 'root'
})
export class WebsocketService {
  private webSocketEndPoint = `${BASE_URL}/${END_POINTS.WEB_SOCKET}`;
  private stompConfig: StompConfig = {
    url: '',
    headers: {},
    heartbeat_in: 0,
    heartbeat_out: 20000,
    reconnect_delay: 5000,
    debug: true,
  };

  constructor(private stompService: StompRService) {
    this.stompConfig.url = () => new SockJS(this.webSocketEndPoint);
    this.stompService.config = this.stompConfig;
    this.stompService.initAndConnect();
  }

  public observeTopic(topic: string): Observable<Message> {
    topic = `/${BASE_TOPIC}/${topic}`;
    return this.stompService.subscribe(topic);
  }

  public observeRequestTopic(topic: string): void {
    topic = `/${BASE_TOPIC}/${topic}`;
    this.stompService.subscribe(topic).subscribe();
  }

  public boundedDebounce<T>(
    source: Observable<T>,
    debounceTimeValue: number = APP_CONSTANTS.DEBOUNCE_TIME,
  ): Observable<T> {
    const debounce$: Observable<T> = source.pipe(debounceTime(debounceTimeValue));

    const sliding$ = source.pipe(
      mapTo(true),
      merge(debounce$.pipe(mapTo(false))),
      distinctUntilChanged(),
    );

    const sampler$ = sliding$.pipe(
      switchMap(active => (active ? source.pipe(auditTime(APP_CONSTANTS.MAX_REFRESH_INTERVAL)) : NEVER)),
    );

    return debounce$.pipe(merge(sampler$));
  }

  public initializedBoundedDebounce<T>(source: Observable<T>, debounceDelay?: number): Observable<T> {
    return of(null).pipe(merge(this.boundedDebounce(source, debounceDelay)));
  }
}
