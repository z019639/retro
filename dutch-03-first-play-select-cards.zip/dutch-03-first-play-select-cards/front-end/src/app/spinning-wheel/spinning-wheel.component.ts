import {Component, OnInit, ViewChild, HostListener} from '@angular/core';
import {NgxWheelComponent, TextOrientation, TextAlignment} from 'ngx-wheel';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-spinning-wheel',
  templateUrl: './spinning-wheel.component.html',
  styleUrls: ['./spinning-wheel.component.scss']
})
export class SpinningWheelComponent implements OnInit {
  @ViewChild(NgxWheelComponent, {static: false})
  wheel;

  members: string[] = [];
  hasPreparedWheel = false;
  canShowWheel = false;
  isOnWheelBreak = false;
  idToLandOn: any;
  items: any[] = [];
  textOrientation: TextOrientation = TextOrientation.HORIZONTAL;
  textAlignment: TextAlignment = TextAlignment.OUTER;

  private colors = ['#FF3051', '#FFD422'];

  constructor(private toastrService: ToastrService) {}
  ngOnInit(): void {
    this.members = ['test', 'test1', 'test2', 'test3', 'test4', 'test5', 'test6', 'test7', 'test8', 'test9', 'test10'];
  }

  @HostListener('keydown', ['$event'])
  onKeydownHandler(event: KeyboardEvent): void {
    if (event.ctrlKey) {
      this.addMember();
    }
  }

  addMember(): void {
    if (this.members.length <= 25) {
      if (this.members.indexOf('') === -1) {
        this.members.push('');
      } else {
        this.toastrService.warning('Cannot add with existing empty member name');
      }
    } else {
      this.toastrService.warning('Limit exceeded');
    }
  }

  editMember(member: string, index: number) {
    this.members[index] = member;
  }

  removeMember(index: number): void {
    this.members = this.members.filter((member, filterIndex) => index !== filterIndex);
    this.items = this.members;
  }

  openMemberModal(): void {
    this.canShowWheel = false;
  }

  setupWheel(): void {
    this.isOnWheelBreak = true;
    this.items = this.members.map((value, index) => ({
      fillStyle: this.colors[index % 2],
      text: `${value}`,
      id: value,
      textFillStyle: 'white',
      strokeStyle: this.colors[index % 2],
      textFontSize: '16'
    }));
    this.idToLandOn = this.members[Math.floor(Math.random() * this.members.length)];
    this.canShowWheel = true;
    this.hasPreparedWheel = true;
  }

  reset() {
    this.wheel.reset();
  }

  before() {}

  startSpin() {
    this.isOnWheelBreak = true;
    this.wheel.spin();
  }

  after() {
    this.isOnWheelBreak = false;
    setTimeout(() => {
      document.getElementsByClassName('announce-result')[0].classList.add('on-going');
    }, 0);
    this.popperShow();
    setTimeout(() => {
      this.canShowWheel = false;
      setTimeout(() => {
        document.getElementById('confetti').classList.add('d-none');
        document.getElementsByClassName('announce-result')[0].classList.remove('on-going');
        this.isOnWheelBreak = true;
        this.members = this.members.filter(member => member !== this.idToLandOn);
        this.setupWheel();
        this.idToLandOn = this.members[Math.floor(Math.random() * this.members.length)];
      }, 0);
    }, 13000);
  }

  popperShow(): void {
    let canShowConfetti = true;
    setTimeout(() => {
      canShowConfetti = false;
    }, 9000);
    document.getElementById('confetti').classList.remove('d-none');

    function rand(min, max) {
      return Math.random() * (max - min) + min;
    }

    const confetti = document.getElementById('confetti') as HTMLCanvasElement;
    const confettiCtx = confetti.getContext('2d');
    let container, confettiElements = [], clickPosition;

    const confettiParams = {
      number: 250,
      size: {x: [3, 10], y: [5, 8]},
      initSpeed: 35,
      gravity: 0.75,
      drag: 0.08,
      terminalVelocity: 6,
      flipSpeed: 0.06,
    };
    const colors = [
      {front: '#00ccff', back: '#089bbf'},
      {front: '#4782ff', back: '#345bad'},
      {front: '#997df5', back: '#6951b5'},
      {front: '#f492fc', back: '#b13fba'},
      {front: '#ff3b7c', back: '#cc2b60'},
      {front: '#00ff33', back: '#05b529'},
      {front: '#bee800', back: '#8aa803'},
      {front: '#f6fa07', back: '#a8ab07'},
      {front: '#ffa200', back: '#db8b00'},
      {front: '#ff6905', back: '#cc5e14'},
      {front: '#e62510', back: '#b01909'},
    ];

    setupCanvas();
    updateConfetti();
    function Conf() {
      this.randomModifier = rand(-1, 1);
      this.colorPair = colors[Math.floor(rand(0, colors.length))];
      this.dimensions = {
        x: rand(confettiParams.size.x[0], confettiParams.size.x[1]),
        y: rand(confettiParams.size.y[0], confettiParams.size.y[1]),
      };
      this.position = {
        x: clickPosition[0],
        y: clickPosition[1]
      };
      this.rotation = rand(0, 2 * Math.PI);
      this.scale = {x: 1, y: 1};
      this.velocity = {
        x: rand(-confettiParams.initSpeed, confettiParams.initSpeed) * 0.4,
        y: rand(-confettiParams.initSpeed, confettiParams.initSpeed)
      };
      this.flipSpeed = rand(0.2, 1.5) * confettiParams.flipSpeed;

      if (this.position.y <= container.h) {
        this.velocity.y = -Math.abs(this.velocity.y);
      }

      this.terminalVelocity = rand(1, 1.5) * confettiParams.terminalVelocity;

      this.update = function () {
        this.velocity.x *= 0.98;
        this.position.x += this.velocity.x;

        this.velocity.y += (this.randomModifier * confettiParams.drag);
        this.velocity.y += confettiParams.gravity;
        this.velocity.y = Math.min(this.velocity.y, this.terminalVelocity);
        this.position.y += this.velocity.y;

        this.scale.y = Math.cos((this.position.y + this.randomModifier) * this.flipSpeed);
        this.color = this.scale.y > 0 ? this.colorPair.front : this.colorPair.back;
      };
    }

    function updateConfetti() {
      confettiCtx.clearRect(0, 0, container.w, container.h);
      confettiElements.forEach((c) => {
        c.update();
        confettiCtx.translate(c.position.x, c.position.y);
        confettiCtx.rotate(c.rotation);
        const width = (c.dimensions.x * c.scale.x);
        const height = (c.dimensions.y * c.scale.y);
        confettiCtx.fillStyle = c.color;
        confettiCtx.fillRect(-0.5 * width, -0.5 * height, width, height);
        confettiCtx.setTransform(1, 0, 0, 1, 0, 0);
      });

      confettiElements.forEach((c, idx) => {
        if (c.position.y > container.h ||
          c.position.x < -0.5 * container.x ||
          c.position.x > 1.5 * container.x) {
          confettiElements.splice(idx, 1);
        }
      });
      window.requestAnimationFrame(updateConfetti);
    }

    function setupCanvas() {
      container = {
        w: confetti.clientWidth,
        h: confetti.clientHeight
      };
      confetti.width = container.w;
      confetti.height = container.h;
    }

    function addConfetti(e) {
      const canvasBox = confetti.getBoundingClientRect();
      if (e) {
        clickPosition = [
          e.clientX - canvasBox.left,
          e.clientY - canvasBox.top
        ];
      } else {
        clickPosition = [
          canvasBox.width * Math.random(),
          canvasBox.height * Math.random()
        ];
      }
      for (let i = 0; i < confettiParams.number; i++) {
        confettiElements.push(new Conf());
      }
    }

    confettiLoop();
    function confettiLoop() {
      if(canShowConfetti) {
        addConfetti(null);
        setTimeout(confettiLoop, 700 + Math.random() * 1700);
      }
    }
  }
}
