import {HttpClient} from '@angular/common/http';
import {Injectable} from '@angular/core';
import {Observable} from 'rxjs';
import {BASE_URL, API_BASE, END_POINTS, TOPICS} from '../app-constants';
import {UpsertMemberDto, Card} from './member';
import {WebsocketService} from '../websocket.service';
import {ResultDto} from '../team/team';

@Injectable({
  providedIn: 'root',
})
export class MemberService {
  private memberSource$;

  constructor(
    private httpClient: HttpClient,
    private websocketService: WebsocketService
  ) {
    this.memberSource$ = this.websocketService.observeTopic(TOPICS.MEMBERS);
  }

  updateById(memberId: number, card: Card): Observable<number> {
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.MEMBER}/${memberId}/${END_POINTS.UPDATE_CARDS}`;
    return this.httpClient.post<number>(url, card);
  }

  deleteCardByIdAndIndex(memberId: number, index: number): Observable<ResultDto> {
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.MEMBER}/${memberId}/${END_POINTS.DELETE_CARDS}/${index}`;
    return this.httpClient.post<ResultDto>(url, {});
  }

  addVoteByCardIndexAndMemberId(memberId: number, cardCreator: number, index: number): Observable<ResultDto> {
    const url = `${BASE_URL}/${API_BASE}/${END_POINTS.MEMBER}/${cardCreator}/${END_POINTS.ADD_VOTE}/${index}`;
    return this.httpClient.post<ResultDto>(url, memberId);
  }
}
