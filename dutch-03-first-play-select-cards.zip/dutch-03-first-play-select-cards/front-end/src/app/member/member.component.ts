import { Component, ViewEncapsulation } from '@angular/core';
import {UpsertMemberDto} from './member';
import {MemberService} from './member.service';
import {Router} from '@angular/router';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-member',
  templateUrl: './member.component.html',
  styleUrls: ['./member.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MemberComponent {
  member: UpsertMemberDto = new UpsertMemberDto();
  isLogin = true;
}
