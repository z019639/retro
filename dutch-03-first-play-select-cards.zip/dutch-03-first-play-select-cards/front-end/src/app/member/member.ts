import {TeamDto} from '../team/team';

export enum MemberState {
  ONLINE = 'ONLINE',
  OFFLINE = 'OFFLINE',
  IN_TEAM = 'IN_TEAM',
  PLAYING = 'PLAYING'
}

export class MemberDto {
  _id: number;
  name: string;
  password: string;
  state: MemberState;
  cards: Card[];
  createdAt: Date;
  updatedAt: Date;
}

export class UpsertMemberDto {
  name: string;
  password: string;
  state: MemberState = MemberState.ONLINE;
  team: TeamDto = null;
}

export class Card {
  note = '';
  index = 0;
  votes: string[] = [];
}

export class CardDisplay {
  note = '';
  index = 0;
  cardIndex = 0;
  votes = [];
  member: string;
  memberId: number;
}
