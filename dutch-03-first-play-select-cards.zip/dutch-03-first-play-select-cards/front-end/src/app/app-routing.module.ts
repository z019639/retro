import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {TeamComponent} from './team/team.component';
import {MemberComponent} from './member/member.component';
import {TeamSetupComponent} from './team/team-setup/team-setup.component';
import {DashboardComponent} from './dashboard/dashboard.component';
import {SpinningWheelComponent} from './spinning-wheel/spinning-wheel.component';

const routes: Routes = [
  {path: '', pathMatch: 'full', redirectTo: 'dashboard'},
  {path: 'dashboard', component: DashboardComponent},
  {path: 'spin-wheel', component: SpinningWheelComponent},
  {path: 'team', component: TeamComponent},
  {path: 'team/:teamId/team-setup', component: TeamSetupComponent},
  {path: 'member', component: MemberComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
