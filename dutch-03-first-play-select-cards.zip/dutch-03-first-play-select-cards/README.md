# Cards online game

It's an application to enable a platform for the online dutch game. 

## What do we have in here?

Users can play a realtime delay less online game with his/her RNTBCI friends.
It shows all status of users and playing status of teams.

## What is a dutch game?
> Its a card-based game with simple rules helps improving focus and memory skills.

the ultimate goal of this game is to have lesser numbers(in total) in the player stack cards and try to eliminate all the cards. once all the cards are eliminated from a player's stack he/she is declared as a winner of the game.
Keeping card numbers in mind will help you keep a lesser number, keeping other's numbers in mind will give you the possibility to win the game easily.

## What are the requirements?
- one or more deck of cards
- 2+ players

## How to play a dutch game?
- shuffle the card deck well
- provide 4 cards per member.
- put the remaining cards (back side facing) in the middle.
- flip one card from the deck and put it next to the deck.
- choose one player and ask him to start.
> When the game starts, there's only one card that is revealed to the players.

## What are the rules?
- before starting the game but after the distribution of cards, players are allowed to see any 2 of their cards with a count down (player need to keep the card position and number in mind)
- now the player can choose one of his/her cards to interchange with the deck or with the revealed card
> Here the card player has chosen from his/her hands will be moved to the revealed card slot and the next players can use or take that card.
- you can use/apply some powers on some specific cards on some specific scenarios
- applying powers is mandatory and you cannot skip it.
- When a player said "DUTCH" before he starts his turn, that will be the last round of the game and at the end of the round all cards of all players will be revealed and the smallest count holder is the winner.
- if the player who said Dutch was not the winner, then he will be given one penalty card at his next game.

## How to reduce cards?
in the game cycle when you see a number or letter for example 3 or K card in the revealed stack and you know that you also have the same number or the letter, you can stop others and put a match.
> while matching a card you no need to replace your card. so your card count will be reduced by one.

## What are powers and how to apply it?
When you *MATCH* the letter cards **D**, **V**, **C** you gain power applying option **or** you can also gain power by replacing these letter cards that you have with the deck of cards(which you don't know the number).
- When you gain power from **V** card you can interchange one of your cards with any one of the other players.
- When you gain power from **C** card you can interchange 2 other players' cards.
- When you apply power from **D** card you can see anyone of your cards.

## What are the numbers and letters?
> 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, K(black)-14, K(red)-0, D-13, C-12 and V-11
## License
[MIT](https://choosealicense.com/licenses/mit/)