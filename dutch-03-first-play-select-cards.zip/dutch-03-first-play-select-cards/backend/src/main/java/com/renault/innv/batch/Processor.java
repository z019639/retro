package com.renault.innv.batch;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.renault.innv.entity.TeamEntity;

@Component
public class Processor implements ItemProcessor<TeamEntity, TeamEntity> {
    @Override
    public TeamEntity process(TeamEntity team) throws Exception {
        return team;
    }
}
