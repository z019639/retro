package com.renault.innv.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.renault.innv.entity.MemberEntity;
import com.renault.innv.entity.TeamEntity.State;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TeamDto implements Serializable{
    private static final long serialVersionUID = 5390860076689163502L;

    private long _id;
	
	@Getter
	@Setter
	private String name;
	
	@Getter
    @Setter
	private String[] columnNames;
	
	@Getter
    @Setter
	private String[] columnColours;
	
	@Getter
    @Setter
	private String joiningId;
	
	@Getter
	@Setter
	private Date countDownStarted;
	
	@Getter
	@Setter
	private int countDownMinutes;
	
	@Getter
	@Setter
	private State state;
	
	private List<MemberDto> members;
	
	private MemberDto createdBy;
	
	private Date createdAt;
	private Date updatedAt;
}
