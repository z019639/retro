package com.renault.innv.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.renault.innv.dto.TeamDto;
import com.renault.innv.entity.TeamEntity;

@Mapper(componentModel="spring")
public interface TeamMapper {
	
	@Mappings({
		@Mapping(target = "members", ignore = true)
	})
	TeamEntity dtoToEntity(TeamDto teamDto);
	
	@Mappings({
		@Mapping(target = "members", ignore = true)
	})
	TeamDto entityToDto(TeamEntity team);
}
