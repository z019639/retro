package com.renault.innv.batch;

import java.util.List;

import org.springframework.batch.item.ItemReader;

public class BatchItemReader<T> implements ItemReader<T> {

    List<T> items;

    public BatchItemReader(List<T> items) {
        this.items = items;
    }

    public T read() throws Exception {

        if (!items.isEmpty()) {
            return items.remove(0);
        }
        return null;
    }
}
