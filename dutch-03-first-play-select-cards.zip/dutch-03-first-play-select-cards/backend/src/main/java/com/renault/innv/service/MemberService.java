package com.renault.innv.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.core.MessageSendingOperations;
import org.springframework.stereotype.Service;

import com.renault.innv.dto.CardDto;
import com.renault.innv.dto.MemberDto;
import com.renault.innv.entity.MemberEntity;
import com.renault.innv.entity.TeamEntity;
import com.renault.innv.entity.TeamEntity.State;
import com.renault.innv.mapper.MemberMapper;
import com.renault.innv.repository.MemberRepository;

import io.vavr.control.Option;
import io.vavr.control.Try;

@Service
public class MemberService {

	@Autowired
	private MemberRepository memberRepository;
	
	@Autowired
	private MemberMapper memberMapper;
	
	@Autowired
	private TeamService teamService;
	
	@Autowired
    @Qualifier("socketSendingOperation")
    private MessageSendingOperations<String> messageSendingOperations;
	
	public CardDto[] getCardsForSelectedIndex(long memberId, int[] selectedIndex) {
	    Optional<MemberEntity> memberOption = memberRepository.findById(memberId);
	    if(!memberOption.isPresent()) {
	        return null;
	    }
	    MemberEntity member = memberOption.get();
	    CardDto[] cards = member.getCards();
	    CardDto[] selectedCards = new CardDto[4];
	    int index = 0;
	    while(index < 2) {
	        selectedCards[selectedIndex[index]] = cards[selectedIndex[index]];
	        index++;
	    }
	    return selectedCards;
	}
	
	public Try<Long> add(MemberDto memberDto) {
		return save(memberMapper.dtoToEntity(memberDto))
				.map(member -> {
				    Try<TeamEntity> team = teamService.findById(memberDto.getTeam().get_id());
				    member.setTeam(team.get());
				    save(member);
				    sendWebsocketUpdateMembers(member.get_id());
				    return member.get_id();
				})
				.onFailure(exception -> new Exception("Failed to save", exception));
	}
	
	public Try<MemberEntity> updateTeamId(MemberEntity member) {
	    return save(member)
        .onFailure(exception -> new Exception("Failed to save", exception));
	}
	
	public Try<MemberEntity> save(MemberDto memberDto) {
	    memberDto.setState(com.renault.innv.entity.MemberEntity.State.IN_TEAM);
        return save(memberMapper.dtoToEntity(memberDto))
                .map(member -> {
                    if(memberDto.getTeam() != null) {
                        Try<TeamEntity> team = teamService.findById(memberDto.getTeam().get_id());
                        member.setTeam(team.get());
                        save(member);
                    }
                    sendWebsocketUpdateMembers(member.get_id());
                    return member;
                })
                .onFailure(exception -> new Exception("Failed to save", exception));
    }
	
	public Try<Long> updateTeamAndStateById(long memberId, MemberDto memberDto) {
	    Optional<MemberEntity> member = memberRepository.findById(memberId);
	    if(!member.isPresent()) {
	        return Try.failure(new Exception("Member not found!"));
	    }
	    
	    TeamEntity team = TeamEntity.builder()
	            ._id(memberDto.getTeam().get_id())
	            .build();

	    member.get().setTeam(team);
	    member.get().setState(memberDto.getState());

        return save(member.get())
                .map(savedMember -> {
                    sendWebsocketUpdateTeams(memberDto.getTeam().get_id());
                    sendWebsocketUpdateMembers(savedMember.get_id());
                    return savedMember.get_id();
                })
                .onFailure(exception -> new Exception("Failed to update", exception));
    }
	
	public Try<Long> updateCardsById(long id, CardDto card) {
	    MemberEntity member = memberRepository.findById(id).get();
	    
	    if(member.getCards() == null) {
	        CardDto[] cards = new CardDto[1];
	        cards[0] = card;
	        member.setCards(cards);
	    }else {
	        CardDto[] existingCards = member.getCards();
	        List<CardDto> cardsList = new ArrayList<>(); 
	        Collections.addAll(cardsList, existingCards); 
	        cardsList.add(card);
	        CardDto[] cards = new CardDto[cardsList.size()];
	        member.setCards(cardsList.toArray(cards));
	    }	    
	    
	    save(member);
	    TeamEntity team = teamService.findById(member.getTeam().get_id()).get();
	    team.setState(State.STARTED);
	    teamService.updateTeam(team);
	    sendWebsocketUpdate(id+"");
	    return Try.success(id);
	}
	
	public void deleteCardByIdAndIndex(long id, int index) {
	    MemberEntity member = memberRepository.findById(id).get();
        CardDto[] existingCards = member.getCards();
        List<CardDto> cardsList = new ArrayList<>(); 
        Collections.addAll(cardsList, existingCards); 
        cardsList.remove(index);
        CardDto[] cards = new CardDto[cardsList.size()];
        member.setCards(cardsList.toArray(cards));
        save(member);
        sendWebsocketUpdate(id+"");
	}
	
	public void addVotesById(Long id, long creatorId, int index) {
        MemberEntity member = memberRepository.findById(creatorId).get();
        CardDto[] existingCards = member.getCards();
        List<CardDto> cardsList = new ArrayList<>(); 
        Collections.addAll(cardsList, existingCards); 
        Set<Long> votes = cardsList.get(index).getVotes();
        if(votes.contains(id)) {
            votes.remove(id);
        } else {
            votes.add(id);
        }
        cardsList.get(index).setVotes(votes);
        CardDto[] cards = new CardDto[cardsList.size()];
        member.setCards(cardsList.toArray(cards));
        save(member);
        sendWebsocketUpdate(id+"");
    }
	
	public Option<MemberEntity> findById(long id){
	    return Option.ofOptional(memberRepository.findById(id));
	}
	
	public Try<MemberEntity> save(MemberEntity member) {
	    if(member.getName() != null || member.getName().equals("null")) {
	        return Try.success(memberRepository.save(member));
	    } else {
	        Option<MemberEntity> memberOption = memberRepository.findBy_id(member.get_id());
	        if (memberOption.isDefined()) {
	            member.setName(memberOption.get().getName());
	            return Try.success(memberRepository.save(member));
	        } else {
	            return Try.failure(new Exception("Invalid member!"));
	        }
	    }
	}
    
	private void sendWebsocketUpdate(String teamId) {
        messageSendingOperations.convertAndSend("/topic/teams", teamId);
    }
	
	private void sendWebsocketUpdateTeams(long teamId) {
        messageSendingOperations.convertAndSend("/topic/teams/"+teamId, teamId);
    }
	
	private void sendWebsocketUpdateMembers(long memberId) {
        messageSendingOperations.convertAndSend("/topic/members", memberId);
    }
}
