package com.renault.innv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.renault.innv.dto.ResultDto;
import com.renault.innv.dto.TeamDto;
import com.renault.innv.exception.HandleException;
import com.renault.innv.service.TeamService;

@CrossOrigin("*")
@RestController
@RequestMapping("api/team")
@Controller
public class TeamController {
	@Autowired
	private TeamService teamService;
	
	@GetMapping
	public ResponseEntity<String> health() {
	    return ResponseEntity.ok().body("Hi");
	}
	
	@GetMapping("/{searchString}/dashboard")
	public ResponseEntity<List<TeamDto>> getDashboardData(@PathVariable("searchString") String searchString) {
		return ResponseEntity.ok().body(teamService.getAll(searchString));
	}
	
	@PostMapping()
	public ResponseEntity<String> add(@RequestBody @Validated TeamDto teamDto) {
		return teamService.add(teamDto)
				.map(teamId -> ResponseEntity.status(HttpStatus.CREATED).body(teamId.toString()))
				.getOrElseGet(HandleException::handleException);
	}
	
	@PostMapping("/update")
    public ResponseEntity<String> update(@RequestBody @Validated TeamDto teamDto) {
        return teamService.update(teamDto)
                .map(teamId -> ResponseEntity.status(HttpStatus.ACCEPTED).body(teamId.toString()))
                .getOrElseGet(HandleException::handleException);
    }
	
	@PostMapping("/{id}/start-count-down")
    public ResponseEntity<ResultDto> startCountDown(@RequestBody @Validated int limit, @PathVariable("id") long id) {
        teamService.startCountDown(id, limit);
        return ResponseEntity.status(HttpStatus.OK).body(ResultDto.builder().build());
    }
	
	@PostMapping("/{id}/cancel-count-down")
    public ResponseEntity<ResultDto> cancelCountDown(@PathVariable("id") long id) {
        teamService.cancelCountDown(id);
        return ResponseEntity.status(HttpStatus.OK).body(ResultDto.builder().build());
    }
	
	@PostMapping("/{id}/change-column-color/{column-index}")
    public ResponseEntity<ResultDto> changeColumnColor(@RequestBody @Validated String selectedColor, @PathVariable("id") long id, @PathVariable("column-index") int columnIndex) {
        teamService.changeColumnColor(id, columnIndex, selectedColor);
        return ResponseEntity.status(HttpStatus.OK).body(ResultDto.builder().build());
    }
	
	@GetMapping("/{id}")
	public ResponseEntity<TeamDto> getById(@PathVariable("id") long id) {
	    return teamService.getById(id)
	            .map(team -> ResponseEntity.ok().body(team))
	            .getOrElseGet(HandleException::handleException);
	}
	
	@GetMapping("/{id}/{joiningId}/{memberName}")
    public ResponseEntity<Long> joinTeam(@PathVariable("id") long id, @PathVariable("joiningId") String joiningId, @PathVariable("memberName") String memberName) {
        return teamService.joinTeam(id, joiningId, memberName)
                .map(result -> ResponseEntity.ok().body(result))
                .getOrElseGet(HandleException::handleException);
    }
	
	@GetMapping("/{id}/joining-code")
    public ResponseEntity<ResultDto> getJoiningCode(@PathVariable("id") long id) {
        return teamService.getJoiningCode(id)
                .map(result -> ResponseEntity.ok().body(result))
                .getOrElseGet(HandleException::handleException);
    }
}
