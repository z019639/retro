package com.renault.innv.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.renault.innv.entity.TeamEntity;

@Repository
public interface TeamRepository extends JpaRepository<TeamEntity, Long>{
    List<TeamEntity> findAllByOrderByUpdatedAtDesc();
    List<TeamEntity> findByNameContainingOrderByUpdatedAtDesc(String name);
}
