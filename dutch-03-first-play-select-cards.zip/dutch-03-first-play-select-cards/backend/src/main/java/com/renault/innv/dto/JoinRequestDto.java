package com.renault.innv.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class JoinRequestDto {
	
	private long teamId;
	
	private String teamName;
	
	private long requestToMemberId;
	
	private String requesterName;
	
}
