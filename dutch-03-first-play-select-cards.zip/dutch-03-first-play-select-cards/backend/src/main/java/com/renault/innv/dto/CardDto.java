package com.renault.innv.dto;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class CardDto implements Serializable {
    
    private static final long serialVersionUID = -3969397943295111007L;
    @Getter
    @Setter
    private String note;
    
    @Getter
    @Setter
	private int index;
    
    @Getter
    @Setter
    private Set<Long> votes;
}
