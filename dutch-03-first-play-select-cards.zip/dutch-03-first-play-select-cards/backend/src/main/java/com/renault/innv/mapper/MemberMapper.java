package com.renault.innv.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

import com.renault.innv.dto.MemberDto;
import com.renault.innv.entity.MemberEntity;

@Mapper(componentModel="spring")
public interface MemberMapper {	
	@Mappings({
		@Mapping(target = "team", ignore = true),
		@Mapping(target = "cards", ignore = true)
	})
	MemberEntity dtoToEntity(MemberDto memberDto);
	
	@Mappings({
		@Mapping(target = "team", ignore = true),
	})
	MemberDto entityToDto(MemberEntity member);
	
	List<MemberDto> dtosToEntities(List<MemberEntity> members);
}
