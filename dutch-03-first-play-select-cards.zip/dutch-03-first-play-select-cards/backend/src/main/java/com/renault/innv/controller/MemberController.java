package com.renault.innv.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.renault.innv.dto.CardDto;
import com.renault.innv.dto.ResultDto;
import com.renault.innv.exception.HandleException;
import com.renault.innv.service.MemberService;

@CrossOrigin("*")
@RestController
@RequestMapping("api/member")
@Controller
public class MemberController {
	@Autowired
	private MemberService memberService;
	
	@PostMapping("/{id}/update-cards")
    public ResponseEntity<Long> updateCardsById(@RequestBody @Validated CardDto card, @PathVariable("id") long id) {
        return memberService.updateCardsById(id, card)
                .map(result -> ResponseEntity.ok().body(result))
                .getOrElseGet(HandleException::handleException);
    }
	
	@PostMapping("/{id}/delete-card/{card-index}")
    public ResponseEntity<ResultDto> deleteCardByIndex(@PathVariable("id") long id, @PathVariable("card-index") int index) {
        memberService.deleteCardByIdAndIndex(id, index);
        return ResponseEntity.ok().body(ResultDto.builder().build());
    }
	
	@PostMapping("/{creator-id}/add-vote/{card-index}")
    public ResponseEntity<ResultDto> addVote(@RequestBody @Validated Long memberId, @PathVariable("creator-id") long cardCreatorId,  @PathVariable("card-index") int index) {
        memberService.addVotesById(memberId, cardCreatorId, index);
        return ResponseEntity.ok().body(ResultDto.builder().build());
    }
}
