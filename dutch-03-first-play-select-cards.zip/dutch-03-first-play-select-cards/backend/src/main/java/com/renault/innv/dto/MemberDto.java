package com.renault.innv.dto;

import java.io.Serializable;
import java.util.Date;

import com.renault.innv.entity.MemberEntity.State;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class MemberDto implements Serializable{
    
    private static final long serialVersionUID = 5929022343838001739L;

    private long _id;
	
	@Getter
	@Setter
	private String name;
	
	@Setter
	@Getter
	private String password;
	
	@Getter
	@Setter
	private State state;
	
	@Getter
    @Setter
    private CardDto[] cards;
	
	@Getter
	@Setter
	private TeamDto team;
	
	private Date createdAt;
	private Date updatedAt;
}
