package com.renault.innv.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.core.MessageSendingOperations;
import org.springframework.stereotype.Service;

import com.renault.innv.dto.CardDto;
import com.renault.innv.dto.MemberDto;
import com.renault.innv.dto.ResultDto;
import com.renault.innv.dto.TeamDto;
import com.renault.innv.entity.MemberEntity;
import com.renault.innv.entity.MemberEntity.State;
import com.renault.innv.entity.TeamEntity;
import com.renault.innv.mapper.MemberMapper;
import com.renault.innv.mapper.TeamMapper;
import com.renault.innv.repository.TeamRepository;

import io.vavr.control.Option;
import io.vavr.control.Try;

@Service
public class TeamService {

	@Autowired
	private TeamRepository teamRepository;
	
	@Autowired
	private TeamMapper teamMapper;
	
	@Autowired
	private MemberService memberService;
	
	@Autowired
	private MemberMapper memberMapper;
	
	@Autowired
    @Qualifier("socketSendingOperation")
    private MessageSendingOperations<String> messageSendingOperations;
	
	public List<TeamDto> getAll(String searchString) {
	    if(searchString.equals("All")) {
	        return teamRepository.findAllByOrderByUpdatedAtDesc()
	                .stream()
	                .map(team -> addMembers(team))
	                .collect(Collectors.toList());
	    } else {
	        return teamRepository.findByNameContainingOrderByUpdatedAtDesc(searchString)
	                .stream()
	                .map(team -> addMembers(team))
	                .collect(Collectors.toList());
	    }
		
	}
	
	public Try<Long> add(TeamDto teamDto) {
	    String joiningId = getJoiningId();
	    teamDto.setJoiningId(joiningId);
	    TeamEntity team = teamMapper.dtoToEntity(teamDto);
	    if(teamDto.getCreatedBy() == null) {
	        return Try.failure(new Exception("can not save"));
	    }
	    if(teamDto.getCreatedBy().get_id() != 0) {
	        Long id = teamDto.getCreatedBy().get_id();
	        Option<MemberEntity> member = memberService.findById(id);
	        if(member.isEmpty()) {
	            MemberEntity savedMember = memberService.save(teamDto.getCreatedBy()).get();
	            team.setCreatedBy(savedMember);
	        }
	        team.setCreatedBy(member.get());
	    } else {
	        MemberEntity savedMember = memberService.save(teamDto.getCreatedBy()).get();
	        team.setCreatedBy(savedMember);
	        team.setCountDownMinutes(10);
	    }
		return Try.of(() -> teamRepository.save(team))
				.map(savedTeam -> {
				    if(teamDto.getCreatedBy().get_id() == 0) {
				        MemberEntity member = team.getCreatedBy();
				        member.setTeam(savedTeam);
				        memberService.updateTeamId(member);
				    }
					sendWebsocketUpdate(savedTeam.get_id().toString());
					return savedTeam.getCreatedBy().get_id();
				})
				.onFailure(exception -> new Exception("Failed to save", exception));
	}
	
	public Try<Long> update(TeamDto teamDto) {
	    Optional<TeamEntity> teamOption = teamRepository.findById(teamDto.get_id());
	    if(!teamOption.isPresent() ) {
	        return Try.failure(new Exception("Team not found"));
	    }
	    
	    TeamEntity team = teamOption.get();
	    team.setName(teamDto.getName());
	    team.setColumnNames(teamDto.getColumnNames());
	    
        return Try.of(() -> teamRepository.save(team))
                .map(savedTeam -> {
                    sendWebsocketUpdate(savedTeam.get_id().toString());
                    return savedTeam.get_id();
                })
                .onFailure(exception -> new Exception("Failed to save", exception));
    }
	
	public Try<TeamDto> getById(long id) {
	    return Try.of(() -> teamRepository.findById(id).get())
	            .map(team -> addMembers(team))
	            .onFailure(exception -> new Exception("Team not found", exception));
	}
	
	public Try<ResultDto> getJoiningCode(long id) {
	    return Try.of(() -> teamRepository.findById(id).get())
                .map(team -> ResultDto.builder().result(team.getJoiningId()).build())
                .onFailure(exception -> new Exception("Team not found", exception));
	}
	
	public Try<TeamEntity> findById(long id) {
        return Try.of(() -> teamRepository.findById(id).get())
                .onFailure(exception -> new Exception("Team not found", exception));
    }
	
	public Try<TeamEntity> getEntityById(long id) {
        return Try.of(() -> teamRepository.findById(id).get())
                .map(team -> team)
                .onFailure(exception -> new Exception("Team not found", exception));
    }
	
	public Try<Long> joinTeam(long id, String joiningId, String memberName) {
        return Try.of(() -> teamRepository.findById(id).get())
                .map(team -> {
                    if(team.getJoiningId().equals(joiningId)) {
                        if(memberName.isEmpty() || memberName.equals(null)) {
                            return null;
                        }
                        TeamDto teamDto = TeamDto.builder()
                                ._id(id)
                                .state(team.getState())
                                .build();
                        MemberDto memberDto = MemberDto.builder()
                                .name(memberName)
                                .team(teamDto)
                                .state(State.IN_TEAM)
                                .build();
                        return memberService.add(memberDto).get();
                    }
                    return 0L;
                })
                .onFailure(exception -> new Exception("Team not found", exception));
    }
	
	public void updateTeam(TeamEntity team) {
	    teamRepository.save(team);
	    sendWebsocketUpdate("UPDATED_TEAM");
	}
	
	public void startCountDown(long teamId, int limit) {
	    TeamEntity team = teamRepository.findById(teamId).get();
	    final long ONE_MINUTE_IN_MILLIS=60000;
	    Calendar date = Calendar.getInstance();
	    long time = date.getTimeInMillis();
	    Date afterAddingTimeMins = new Date(time + (team.getCountDownMinutes() * ONE_MINUTE_IN_MILLIS));
	    team.setCountDownStarted(afterAddingTimeMins);
	    team.setCountDownMinutes(limit);
	    updateTeam(team);
	}
	
	public void cancelCountDown(long teamId) {
        TeamEntity team = teamRepository.findById(teamId).get();
        team.setCountDownStarted(null);
        updateTeam(team);
    }
	
	public void changeColumnColor(long teamId, int columnIndex, String selectedColor) {
        TeamEntity team = teamRepository.findById(teamId).get();
        String[] existingColours = team.getColumnColours();
        List<String> colourList = new ArrayList<>(); 
        Collections.addAll(colourList, existingColours); 
        colourList.set(columnIndex, selectedColor);
        String[] colours = new String[colourList.size()];
        team.setColumnColours(colourList.toArray(colours));
        updateTeam(team);
    }
	
	private TeamDto addMembers(TeamEntity team) {
	    team.getCreatedBy().setTeam(null);
	    TeamDto teamDto = teamMapper.entityToDto(team);
	    List<MemberDto> members = memberMapper.dtosToEntities(team.getMembers());
		teamDto.setMembers(members);
		return teamDto;
	}
	
	private String getJoiningId() {
	    int leftLimit = 48;
        int rightLimit = 122;
        int targetStringLength = 10;
        Random random = new Random();
     
        return random.ints(leftLimit, rightLimit + 1)
          .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
          .limit(targetStringLength)
          .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
          .toString();
	}
	
	private void sendWebsocketUpdate(String teamId) {
        messageSendingOperations.convertAndSend("/topic/teams", teamId);
    }
}
