package com.renault.innv.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.renault.innv.entity.MemberEntity;

import io.vavr.control.Option;
import io.vavr.control.Try;

@Repository
public interface MemberRepository extends JpaRepository<MemberEntity, Long>{
    List<MemberEntity> findBy_idIsNotOrderByStateAsc(long _id);
    
    Option<MemberEntity> findByNameAndPassword(String name, String password);
    
    Option<MemberEntity> findBy_id(long _id);
}
