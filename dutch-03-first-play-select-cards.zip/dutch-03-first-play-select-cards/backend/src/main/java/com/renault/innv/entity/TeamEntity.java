package com.renault.innv.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "team")
public class TeamEntity extends AuditEntity{
	@Id
    @GeneratedValue(generator = "team_generator")
    @SequenceGenerator(
            name = "team_generator",
            sequenceName = "team_sequence",
            initialValue = 5
    )
    private Long _id;
	
	@NotBlank
    @Size(min = 3, max = 200)
    private String name;
	
	private String[] columnNames;
	
	private String[] columnColours;
	
	private String joiningId;
	
	private Date countDownStarted;
	
	private int countDownMinutes;
	
    @NotNull
    private State state;
	
    @OneToMany(mappedBy = "team", cascade = CascadeType.DETACH)
    @OrderBy("_id ASC")
    private List<MemberEntity> members;
    
    @JsonBackReference
    @ManyToOne
    @JoinColumn(name="member_id")
    private MemberEntity createdBy;
	
    public enum State {
        OPEN,
        STARTED,
        CLOSED
    }
}
