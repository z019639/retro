package com.renault.innv.dto;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ResultDto {
    private String result;
}
