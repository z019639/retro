package com.renault.innv.batch;

import java.util.List;

import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.renault.innv.entity.TeamEntity;
import com.renault.innv.repository.TeamRepository;

@Component
public class DBWriter implements ItemWriter<TeamEntity> {

    @Autowired
    private TeamRepository teamRepository;

    @Override
    public void write(List<? extends TeamEntity> teams) throws Exception {
        List<TeamEntity> allTeams = teamRepository.findAll();
        // TODO delete logic 
    }
}
