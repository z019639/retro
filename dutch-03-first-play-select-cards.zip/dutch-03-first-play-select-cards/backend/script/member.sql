-- SEQUENCE: public.member_sequence

-- DROP SEQUENCE public.member_sequence;

CREATE SEQUENCE public.member_sequence
    INCREMENT 50
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE public.member_sequence
    OWNER TO postgres;

-- Table: public.member

-- DROP TABLE public.member;

CREATE TABLE public.member
(
    _id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    cards jsonb,
    has_announced_ready boolean,
    has_raised_match boolean,
    name character varying(200) COLLATE pg_catalog."default",
    state integer NOT NULL,
    team_id bigint,
    CONSTRAINT member_pkey PRIMARY KEY (_id),
    CONSTRAINT members_fk FOREIGN KEY (team_id)
        REFERENCES public.team (_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE public.member
    OWNER to postgres;