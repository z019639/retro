-- SEQUENCE: public.team_sequence

-- DROP SEQUENCE public.team_sequence;

CREATE SEQUENCE public.team_sequence
    INCREMENT 50
    START 1
    MINVALUE 1
    MAXVALUE 9223372036854775807
    CACHE 1;

ALTER SEQUENCE public.team_sequence
    OWNER TO postgres;

-- Table: public.team

-- DROP TABLE public.team;

CREATE TABLE public.team
(
    _id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    name character varying(200) COLLATE pg_catalog."default",
    state integer NOT NULL,
    CONSTRAINT team_pkey PRIMARY KEY (_id)
)

TABLESPACE pg_default;

ALTER TABLE public.team
    OWNER to postgres;