-- Table: public.playground

-- DROP TABLE public.playground;

CREATE TABLE public.playground
(
    _id bigint NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    cards jsonb,
    match_raised boolean,
    next_player_index integer,
    open_card jsonb,
    play jsonb,
    ready_player_count integer,
    state integer,
    team_id bigint,
    CONSTRAINT playground_pkey PRIMARY KEY (_id),
    CONSTRAINT playground_fk FOREIGN KEY (team_id)
        REFERENCES public.team (_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE public.playground
    OWNER to postgres;